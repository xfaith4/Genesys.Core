# Orchestrator Blueprint Diagnostic Console

This bundle contains a standalone browser-based diagnostic console for the UnifiedAIToolbox orchestrator blueprint.

## What it does

- Renders the embedded Markdown blueprint.
- Renders the embedded Mermaid system diagram when the Mermaid CDN is reachable.
- Provides raw Markdown and Mermaid source tabs.
- Adds a local Run Inspector for exported orchestrator artifacts.

## Run Inspector inputs

Drop or select one or more of these files:

- `data/runs/<runId>.json`
- `data/run-events/<runId>.jsonl`
- `data/validation-reports/*.json`
- `data/repair-escalations/*.json`
- `data/traceability-reports/*.json`
- `output/projects/<runId>/.run-manifest.json`

All parsing is done client-side in the browser. No backend server is required.

## Output

The console reconstructs:

- run status and readiness score
- phase and task status
- event timeline
- observed agents
- produced files
- validation results
- repair escalations
- traceability/drift warnings
- diagnostic issues list

Use **Export diagnostic JSON** to save the reconstructed report.
