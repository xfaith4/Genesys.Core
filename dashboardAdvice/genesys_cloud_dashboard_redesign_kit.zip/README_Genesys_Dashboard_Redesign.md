# Genesys Cloud Smoke Dashboard Redesign Kit

Files included:

- `Genesys_Cloud_Smoke_Dashboard_Redesign_Guide.docx` - structured build guide with embedded mockups.
- `mockup_01_command_center.png` - landing page template.
- `mockup_02_alert_evidence.png` - active alert evidence template.
- `mockup_03_domain_drilldown.png` - domain drilldown template.

Core build model: Status -> Alert Evidence -> Scope -> Correlation -> Drilldown -> Runbook.
